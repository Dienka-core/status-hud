fx_version 'bodacious'
game 'gta5'
author 'Dienka'
description 'https://discord.gg/wQpd6aa8ZS'

client_script 'client.lua'

files {
    'ui/*'
}

ui_page 'ui/index.html'